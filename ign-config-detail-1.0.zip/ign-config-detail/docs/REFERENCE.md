# IGN Configurable Detail: reference

## Region attributes

| Attribute | Required | What it does |
|---|---|---|
| Source (SQL Query) | Yes | Main query. Returns one row per record (card). |
| Detail Query | No | The fields of an expanded card. `:PK` is bound to the card's key. |
| LOV Query | No | All option lists. Runs once per page view. |
| Primary Key Column | Yes | Column of the main query that identifies a record. |
| Filter Column | No | Column of the main query whose distinct values become filter chips. |
| Selection Item | No | Hidden page item that receives the selected keys, separated by `;`. When this is empty, cards have no checkboxes. |
| Edits Item | No | Hidden page item (Value Protected = No) that receives the changed values as JSON. |
| Decimal Separator | Yes | `,` or `.` on screen. Values are always sent with `.`. |
| Date Format | No | Format for view-only DATE values. The default is `DD-Mon-YYYY`. |
| Search Placeholder, Record Name, Initial State | No | Search box text; the noun used in messages ("customer" gives "4 customers"); and whether cards start collapsed, with the first expanded, or all expanded. |

Also set the region's **Page Items to Submit** to every page item the queries reference.

## Main query

Every column becomes a summary cell, and the column alias is its heading. These columns are special:

| Column | Meaning |
|---|---|
| *(Primary Key Column)* | Record key. It is bound as `:PK` in the detail query and sent back as `id`. |
| `ROW_VERSION` | Any value that changes when the row changes, for example `ora_hash(...)`. `save_edits` uses it for the lost-update check. |
| `ROW_LABEL` | Name of the record in messages. |
| `SEARCH_TEXT` | Text that the search box matches against. |
| `DATA_<NAME>` | Not shown. Becomes `data-<name>` on the card, so conditions can read it. |

Extra columns named `<CELL>__<SUFFIX>` decorate a cell. For example, `name__sub` puts a second line under `NAME`.

| Suffix | Effect |
|---|---|
| `__SUB`, `__BADGE`, `__PREFIX` | Second line, small tag, muted text before the value |
| `__PILL` | Shows the value as a pill. The suffix value must be `ok`, `warn`, `bad`, `info` or `neutral`. |
| `__CLASS` | CSS classes: `cd-end`, `cd-mono`, `cd-strong`, `cd-sub-bad` |
| `__WIDTH` | Grid width, for example `120px` or `2fr` |
| `__DISPLAY` | Text shown instead of the value |
| `__ITEM`, `__TYPE`, `__LOV`, `__REQ` | Make the cell an input: its key, field type, list and required flag |
| `__LOV_PARENT`, `__REQUIRED_WHEN`, `__READONLY_WHEN`, `__SET_FROM`, `__REFRESH_ON`, `__PLACEHOLDER` | Same meaning as in the detail query |

## Detail query

The detail query can be written in two ways.

### Column mode (simplest)

Select one row, and each column becomes a field. The heading comes from the column alias, and the key is the column name in lower case. Configure a field with extra columns:

```sql
select o.order_no,
       o.status,   'LOV' status__type, 'STATUS' status__lov, 'Y' status__req,
       o.due_date, 'DATE' due_date__type,
       o.remarks,  'TEXTAREA' remarks__type,
       'Order' order_no__group, 'Order' status__group
  from orders o
 where o.id = :PK
```

These suffixes are available: `__TYPE`, `__LOV`, `__REQ`, `__GROUP`, `__LABEL`, `__DISPLAY`, `__ITEM`, `__LOV_PARENT`, `__SHOW_WHEN`, `__REQUIRED_WHEN`, `__READONLY_WHEN`, `__SET_FROM`, `__REFRESH_ON`, `__HELP`, `__NOTE`, `__PLACEHOLDER`.

A column without `__TYPE` is view only. DATE and NUMBER columns are formatted automatically.

### Row mode (one row per field)

Use row mode when fields come from data, or when each field needs its own SQL logic. The query must return `LABEL` and `VALUE`. Fields are grouped by `GROUP_NAME`, in the order the query returns them.

| Column | Meaning |
|---|---|
| `GROUP_NAME`, `LABEL` | Section heading and field label |
| `VALUE` | Stored value as text: numbers with `.` decimals, dates as `YYYY-MM-DD` |
| `DISPLAY_VALUE` | What a view-only field shows instead of `VALUE` |
| `ITEM_KEY` | Name the value is sent back under. Use the table column name. |
| `ITEM_TYPE` | Field type (see below). Null means view only. |
| `IS_REQUIRED` | `Y` means always required |
| `LOV` | A `LOV_NAME` from the LOV query, or inline JSON such as `[{"r":"A","d":"Alpha"}]` |
| `LOV_PARENT`, `SHOW_WHEN`, `REQUIRED_WHEN`, `READONLY_WHEN`, `SET_FROM`, `REFRESH_ON` | Dynamic conditions (see below) |
| `HELP_TEXT`, `NOTE`, `PLACEHOLDER` | Grey help line, amber message line, input placeholder |

### Field types

| Type | Shows as |
|---|---|
| `TEXT` | Text input |
| `NUMBER` | Number input with the region's decimal separator. The value is sent as a JSON number. |
| `TEXTAREA` | Text area |
| `DATE` | Browser date picker. The value is sent as `YYYY-MM-DD`. |
| `LOV` (or `SELECT`) | Select list |
| `DISPLAY` or null | View only. If the field has a key and changes through `SET_FROM` or `REFRESH_ON`, it is still sent back. |
| `HIDDEN` | Not shown. Holds a value that conditions can read. |

Because the type is a column, server-side rules are plain SQL, for example `case when :APP_USER = o.owner then 'TEXT' end`.

## LOV query

Return the columns `LOV_NAME`, `RETURN_VALUE` and `DISPLAY_VALUE`. Two columns are optional:

- `DATA`: a JSON object such as `json_object('cur' value currency_code)`, which `SET_FROM` and conditions can read as `key.prop`.
- `PARENT_VALUE`: used with `LOV_PARENT`.

Several lists can come from one query with `union all`.

## Dynamic conditions

These conditions are checked in the browser after every change in the same card.

| Column | Example | Effect |
|---|---|---|
| `SHOW_WHEN` | `type = B` | The field is shown only while the condition is true. A hidden field is neither validated nor sent. |
| `REQUIRED_WHEN` | `address IS NOT NULL` | Required while true. This is in addition to `IS_REQUIRED`. |
| `READONLY_WHEN` | `state IS NULL` | Locked while true. The value is still sent. |
| `LOV_PARENT` | `country` or `bank.api` | The list keeps only options whose `PARENT_VALUE` is null or equals the parent's value, and it refills when the parent changes. |
| `SET_FROM` | `bank.cur` | Copies a value from `DATA` of the option chosen in another field (`.d` gives that option's label). |
| `REFRESH_ON` | `type,bank` | When one of these fields changes, the detail query runs again for this card and this field is redrawn. |

**Syntax.** A condition is made of comparisons: `key = value`, `key != value`, `key IN (a, b)`, `key NOT IN (a, b)`, `key IS NULL`, `key IS NOT NULL`. Join them with `AND` and `OR`. `AND` binds tighter, and brackets aren't supported. Values can be quoted.

**Keys.** A key can refer to:
- a field key of the same card;
- `key.prop`, which reads `DATA` of the option chosen in that field;
- any other name, which reads the card's `DATA_<NAME>` column.

**REFRESH_ON.** On a refresh, the detail query receives `:CD_REFRESH = 'Y'` and every field's current value as `:<ITEM_KEY>` (in upper case). On the first load these binds are null. For example:

```sql
case when :CD_REFRESH = 'Y' and :DISCOUNT_TYPE = 'STANDARD'
     then to_char(get_standard_discount(:CUSTOMER_TYPE), 'TM9', 'NLS_NUMERIC_CHARACTERS=''.,''')
     when :CD_REFRESH = 'Y' then :DISCOUNT          -- keep what the user typed
     else to_char(o.discount, 'TM9', 'NLS_NUMERIC_CHARACTERS=''.,''')
end
```

## Saving

`apex.region("<static id>").submit({ request: "SAVE", validate: true })` checks required fields. It then writes only the changed fields into the Edits Item and submits the page. The Edits Item receives JSON like this:

```json
[{"id":"12","version":"3141592","email":"new@example.com","due_date":"2026-12-31"}]
```

An After Submit process saves it:

```sql
declare
    l_rows pls_integer;
begin
    l_rows := ign_config_detail.save_edits(
                  p_edits        => :P10_EDITS,
                  p_table_name   => 'MY_TABLE',
                  p_pk_column    => 'ID',
                  p_columns      => 'STATUS,DUE_DATE,AMOUNT',     -- or 'key=COLUMN,...'
                  p_version_expr => 'ora_hash(status || due_date || amount)',  -- optional
                  p_where        => q'[status <> 'CLOSED']',       -- optional
                  p_record_name  => 'Order' );
end;
```

- Only keys listed in `p_columns` are written. Anything else in the JSON is ignored.
- Values are converted by the column's data type: DATE from `YYYY-MM-DD`, NUMBER with `.` decimals, and everything else as text.
- `p_version_expr` must be the same expression as the main query's `ROW_VERSION`. If a row changed in the meantime, or no longer matches `p_where`, `save_edits` raises ORA-20002 and saves nothing.
- The function returns the number of rows updated.

## JavaScript API

`apex.region("<static id>")` returns an object with these methods:

| Method | What it does |
|---|---|
| `ids()`, `selectedIds()` | Keys of all cards, or of the selected cards |
| `row$(id)` | jQuery object for a card |
| `getValue(id, key)`, `setValue(id, key, value, text)` | Read or set a field. Setting a field runs the same cascade as a user change. |
| `setOptions(id, key, [{r, d, x}])`, `getOption(id, key)` | Replace a list's options, or read the chosen option |
| `setReadOnly(id, key, on)`, `setNote(id, key, text)`, `setBusy(id, on)` | Field and card state |
| `expand(id, open)`, `missing(id)` | Open or close a card; list a card's empty required fields |
| `refreshFields(id, keys)` | Re-run the detail query for some fields of one card |
| `refresh()` | Reload all cards. Unsaved changes are dropped. |
| `submit({request, confirm, validate, verb, selection})` | Fill the Selection and Edits items, then submit the page |

The region fires two events: `cdready` after the cards are set up (including after a refresh), and `cdchange` with `{id, key, value}` after a field changes.

## Troubleshooting

| Error | Cause |
|---|---|
| "the region query has no column named ..." | Primary Key Column doesn't match a column alias of the main query. |
| "the LOV Query needs the columns LOV_NAME, RETURN_VALUE and DISPLAY_VALUE" | The LOV query is missing one of these aliases. |
| A list shows only "- Select -" | The `LOV` name has no rows in the LOV query, or `LOV_PARENT` filters them all out. |
| Conditions do nothing | The browser console shows "cannot read condition". Check the syntax above. |
| Edits are not saved | The Edits Item must be Hidden with Value Protected = No, and the process must run on the request that `submit()` sends. |
