/*
 * IGN Configurable Detail (region plugin COM.IGN.CONFIG_DETAIL)
 *
 * The server renders the cards; this file adds the behaviour:
 *   search, filter chips, expand/collapse, selection, required checks,
 *   field conditions (SHOW_WHEN, REQUIRED_WHEN, READONLY_WHEN), cascading LOVs (LOV_PARENT),
 *   values copied from a selected option (SET_FROM), server refresh of fields (REFRESH_ON),
 *   and submit() which writes the selection and the changes into page items.
 *
 * apex.region("<region static id>") gives the API at the end of this file. The region fires
 *   "cdready"   once the cards are set up (again after every refresh)
 *   "cdchange"  (event, {id, key, value}) after a field value changed
 */
(function ($) {
    "use strict";
    var DASH = "—", BAD = { bad: true }, NEED = "\u0000NEED";

    /* ------------------------------------------------------------------ conditions
       "key = value", "key != value", "key IN (a, b)", "key NOT IN (a, b)",
       "key IS NULL", "key IS NOT NULL", joined with AND / OR (AND binds tighter).
       key is an ITEM_KEY of the same card, "key.prop" reads DATA of the selected option,
       anything else reads the card attribute data-<key> (main query DATA_<KEY> columns). */
    var TERM = /^\s*([A-Za-z0-9_$#.\-]+)\s*(=|!=|<>|NOT\s+IN\b|IN\b|IS\s+NOT\s+NULL\b|IS\s+NULL\b)\s*(.*?)\s*$/i;

    function unquote(s) {
        s = $.trim(String(s == null ? "" : s));
        if (s.length > 1 && (s.charAt(0) === "'" || s.charAt(0) === '"') && s.charAt(s.length - 1) === s.charAt(0)) {
            s = s.substring(1, s.length - 1);
        }
        return s;
    }

    function parseCond(text) {
        if (!text) { return null; }
        return String(text).split(/\s+OR\s+/i).map(function (part) {
            return part.split(/\s+AND\s+/i).map(function (t) {
                var m = TERM.exec(t), op, list;
                if (!m) {
                    apex.debug.warn("IGN Configurable Detail: cannot read condition \"" + t + "\"");
                    return null;
                }
                op = m[2].toUpperCase().replace(/\s+/g, " ");
                if (op === "IN" || op === "NOT IN") {
                    list = m[3].replace(/^\(/, "").replace(/\)$/, "").split(",").map(unquote);
                }
                return { key: m[1], op: op === "<>" ? "!=" : op, value: unquote(m[3]), list: list };
            }).filter(Boolean);
        });
    }

    function evalCond(cond, get) {
        if (!cond) { return null; }
        return cond.some(function (and) {
            return and.every(function (t) {
                var v = get(t.key);
                v = v == null ? "" : String(v);
                switch (t.op) {
                case "=": return v === t.value;
                case "!=": return v !== t.value;
                case "IN": return t.list.indexOf(v) >= 0;
                case "NOT IN": return t.list.indexOf(v) < 0;
                case "IS NULL": return v === "";
                case "IS NOT NULL": return v !== "";
                }
                return false;
            });
        });
    }

    function init(regionId, o) {
        var $reg = $("#" + regionId), $root = $(),
            dec = o.dec === "." ? "." : ",", grp = dec === "," ? "." : ",",
            noun = o.noun || "record", lovs = {}, state = { q: "", f: "" }, seq = {}, condCache = {}, api;

        /* ---------------------------------------------------------------- helpers */
        function rows() { return $root.find(".cd-row"); }
        function row(id) {
            id = String(id);
            return rows().filter(function () { return this.getAttribute("data-id") === id; });
        }
        function fields($r) { return $r.find("[data-k]"); }
        function fld($r, k) {
            k = String(k).toLowerCase();
            return fields($r).filter(function () { return this.getAttribute("data-k").toLowerCase() === k; }).first();
        }
        function wrap($f) { return $f.closest(".cd-f, .cd-c"); }
        function plural(n) { return n === 1 ? noun : noun + "s"; }
        function isInput($f) { return $f.hasClass("cd-in"); }
        function isShown($f) { return !wrap($f).is(".is-off"); }
        function keysOf(s) {
            return String(s || "").toLowerCase().split(",").map($.trim).filter(Boolean);
        }
        function cond($f, attr) {
            var t = $f.attr(attr);
            if (!t) { return null; }
            if (!condCache.hasOwnProperty(t)) { condCache[t] = parseCond(t); }
            return condCache[t];
        }
        function labelOf($f) {
            var t = $f.attr("aria-label");
            if (!t) { t = wrap($f).find(".cd-l").first().text(); }
            return $.trim(String(t || ""));
        }

        /* Numbers are kept as text with "." decimals end to end, so no digit is lost in the browser.
           On screen they use the region's decimal separator. */
        function fixLead(c) { return c.replace(/^(-?)\./, "$10."); }
        function fromData(v) {
            v = $.trim(String(v == null ? "" : v));
            return v === "" ? null : fixLead(v);
        }
        function reEsc(c) { return c === "." ? "\\." : c; }
        function fromInput(s) {
            var d = reEsc(dec), g = reEsc(grp);
            s = String(s == null ? "" : s).replace(/\s/g, "");
            if (s === "") { return null; }
            if (new RegExp("^-?\\d{1,3}(" + g + "\\d{3})+(" + d + "\\d*)?$").test(s)) { s = s.split(grp).join(""); }
            if (!new RegExp("^-?(\\d+(" + d + "\\d*)?|" + d + "\\d+)$").test(s)) { return BAD; }
            return fixLead(s.replace(dec, ".").replace(/\.$/, ""));
        }
        function norm(c) {
            if (c === null || c === BAD) { return ""; }
            var neg = c.charAt(0) === "-", p = c.replace(/^-/, "").split("."),
                i = p[0].replace(/^0+(?=\d)/, ""), f = (p[1] || "").replace(/0+$/, "");
            return (neg ? "-" : "") + i + (f ? "." + f : "");
        }
        function show(c) { return c === null ? "" : c.replace(".", dec); }

        /* ---------------------------------------------------------------- option lists */
        function lovOf($f) {
            var j = $f.attr("data-lovj");
            if (j) {
                try { return JSON.parse(j); } catch (ex) { return []; }
            }
            return lovs[$f.attr("data-lov")] || [];
        }
        /* the list after LOV_PARENT: options whose PARENT_VALUE is null or equals the parent's value */
        function optionsOf($f) {
            var list = lovOf($f), pk = $f.attr("data-lov-parent"), pv;
            if (!pk) { return list; }
            pv = getIn($f.closest(".cd-row"), pk);
            pv = pv == null ? "" : String(pv);
            return list.filter(function (it) { return it.p == null || it.p === "" || String(it.p) === pv; });
        }
        function optionFor(list, v) {
            for (var i = 0; i < list.length; i++) {
                if (String(list[i].r) === v) { return list[i]; }
            }
            return null;
        }

        function fillSelect($s, list, keep) {
            var cur = keep !== undefined ? keep : ($s.val() || $s.attr("data-o") || ""), found = false,
                ph = $s.find("option").first().filter(function () { return this.value === ""; }).text() || "- Select -";
            $s.empty().append($("<option>").val("").text(ph));
            list.forEach(function (it) {
                var $o = $("<option>").val(it.r).text(it.d);
                if (it.x) { $o.data("x", it.x); }
                if (String(it.r) === cur) { found = true; }
                $s.append($o);
            });
            if (cur && !found && keep === undefined && cur === ($s.attr("data-o") || "") && !$s.attr("data-lov-parent")) {
                /* stored value no longer in the list: keep it so nothing is lost silently */
                $s.append($("<option>").val(cur).text($s.attr("data-d") || cur));
                found = true;
            }
            $s.val(found ? cur : "");
            return found || !cur;
        }

        /* ---------------------------------------------------------------- values */
        /* current value: canonical text ("." decimals for numbers), or null */
        function valueOf($f) {
            var v;
            if (!$f || !$f.length) { return null; }
            if (!isInput($f)) { return $f.attr("data-v") || null; }
            if ($f.attr("data-t") === "NUMBER") {
                v = fromInput($f.val());
                return v === BAD ? null : v;
            }
            v = $.trim(String($f.val() || ""));
            return v === "" ? null : v;
        }

        /* DATA of the option currently chosen in a LOV field (also for read-only fields that have a LOV) */
        function dataOf($f) {
            var v = valueOf($f), $o, it;
            if (v === null) { return null; }
            if ($f.is("select")) {
                $o = $f.find("option:checked");
                if ($o.data("x")) { return $o.data("x"); }
            }
            it = optionFor(lovOf($f), v);
            return it ? (it.x || {}) : null;
        }

        /* "key", "key.prop" (DATA of the chosen option; .d = its label) or a card data- attribute */
        function getIn($r, ref) {
            var dot = ref.indexOf("."), $f, x, $o;
            if (dot > 0) {
                $f = fld($r, ref.substring(0, dot));
                if (!$f.length) { return null; }
                if (ref.substring(dot + 1) === "d") {
                    if ($f.is("select")) {
                        $o = $f.find("option:checked");
                        return $o.val() ? $o.text() : null;
                    }
                    x = optionFor(lovOf($f), valueOf($f) || "");
                    return x ? x.d : null;
                }
                x = dataOf($f);
                return x && x[ref.substring(dot + 1)] != null ? String(x[ref.substring(dot + 1)]) : null;
            }
            $f = fld($r, ref);
            if ($f.length) { return valueOf($f); }
            x = $r.attr("data-" + ref.toLowerCase().replace(/_/g, "-"));
            return x === undefined || x === "" ? null : x;
        }

        function changed($f) {
            if ($f.attr("data-t") === "NUMBER") {
                return norm(isInput($f) ? fromInput($f.val()) : fromData($f.attr("data-v"))) !== norm(fromData($f.attr("data-o")));
            }
            return (valueOf($f) || "") !== ($f.attr("data-o") || "");
        }

        function setShown($f, v, text) {
            var t = text != null ? text : (v ? ((optionFor(lovOf($f), v) || {}).d || ($f.attr("data-t") === "NUMBER" ? show(fromData(v)) : v)) : "");
            $f.attr("data-v", v || "").text(t || DASH).toggleClass("cd-empty", !t);
        }

        /* write a value into a field without the change cascade */
        function put($f, v, text) {
            var t = $f.attr("data-t");
            v = v == null ? "" : String(v);
            if (!isInput($f)) { setShown($f, v, text); }
            else if (t === "NUMBER") { $f.val(show(fromData(v))).removeClass("is-invalid"); }
            else if ($f.is("select")) {
                if (v && !$f.find("option").filter(function () { return this.value === v; }).length) {
                    $f.append($("<option>").val(v).text(text || v));
                }
                $f.val(v);
            } else if (t === "DATE") { $f.val(v.substring(0, 10)); }
            else { $f.val(v); }
        }

        function setNote($f, text) {
            var $n = wrap($f).find(".cd-note").first();
            if (!$n.length) {
                $n = $('<p class="cd-note" role="status">');
                wrap($f).append($n);
            }
            $n.text(text || "").prop("hidden", !text);
        }

        /* ---------------------------------------------------------------- conditions per card */
        function isReq($f) {
            var c = cond($f, "data-req-when"), r = evalCond(c, function (k) { return getIn($f.closest(".cd-row"), k); });
            return $f.attr("data-req") === "Y" || r === true;
        }

        function applyConds($r) {
            var get = function (k) { return getIn($r, k); };
            $r.find(".cd-f[data-show-when]").each(function () {
                var on = evalCond(cond($(this), "data-show-when"), get) !== false;
                $(this).toggleClass("is-off", !on).prop("hidden", !on);
            });
            fields($r).each(function () {
                var $f = $(this), ro = evalCond(cond($f, "data-ro-when"), get), req = isReq($f);
                if (isInput($f) && ro !== null) {
                    if ($f.is("select")) { $f.prop("disabled", ro); } else { $f.prop("readOnly", ro); }
                    $f.toggleClass("is-auto", ro);
                }
                wrap($f).toggleClass("is-req", req && !(isInput($f) && ro === true));
                if (isInput($f)) { $f.attr("aria-required", req ? "true" : null); }
            });
        }

        function missing($r) {
            var m = [];
            fields($r).each(function () {
                var $f = $(this);
                if (isShown($f) && wrap($f).hasClass("is-req") && valueOf($f) === null) { m.push(labelOf($f)); }
            });
            return m;
        }

        function refreshNeed($r) {
            var m = missing($r), $p = $r.find(".cd-need"), $at;
            if (!$p.length) {
                $p = $('<span class="cd-pill cd-need" hidden>Needs input</span>');
                $at = $r.find(".cd-c-pill").first();
                if (!$at.length) { $at = $r.find(".cd-c").last(); }
                if ($at.children(".cd-sub").length) { $at.children(".cd-sub").first().before($p); } else { $at.append($p); }
            }
            $r.toggleClass("is-need", m.length > 0);
            $p.prop("hidden", m.length === 0).attr("title", m.length ? "Missing: " + m.join(", ") : null);
        }

        /* ---------------------------------------------------------------- the change cascade */
        function dependents($r, key, attr, byPrefix) {
            key = key.toLowerCase();
            return fields($r).filter(function () {
                var v = (this.getAttribute(attr) || "").toLowerCase();
                if (!v) { return false; }
                if (attr === "data-refresh-on") { return keysOf(v).indexOf(key) >= 0; }
                return byPrefix ? (v === key || v.indexOf(key + ".") === 0) : v === key;
            });
        }

        function afterChange($r, key, depth, noRefresh) {
            var id = $r.attr("data-id"), $f = fld($r, key), refresh = [];
            depth = depth || 0;
            if (depth > 10) { return; }                              /* a loop in the configuration */
            $r.attr("data-dirty", "Y");

            /* LOV_PARENT: refill the child lists */
            dependents($r, key, "data-lov-parent", true).each(function () {
                var $c = $(this), before = valueOf($c);
                if ($c.is("select")) {
                    fillSelect($c, optionsOf($c), before || "");
                    if (valueOf($c) !== before) { afterChange($r, $c.attr("data-k"), depth + 1, noRefresh); }
                }
            });
            /* SET_FROM: copy DATA of the chosen option; back to the original when nothing is chosen */
            dependents($r, key, "data-set-from", false).add(fields($r).filter(function () {
                var s = (this.getAttribute("data-set-from") || "").toLowerCase();
                return s.indexOf(key.toLowerCase() + ".") === 0;
            })).each(function () {
                var $c = $(this), src = $c.attr("data-set-from"), v, before = valueOf($c);
                v = valueOf(fld($r, src.split(".")[0])) === null ? $c.attr("data-o") : getIn($r, src);
                put($c, v);
                if (valueOf($c) !== before) { afterChange($r, $c.attr("data-k"), depth + 1, noRefresh); }
            });
            applyConds($r);
            refreshNeed($r);
            if (!noRefresh) {
                dependents($r, key, "data-refresh-on").each(function () { refresh.push($(this).attr("data-k")); });
                if (refresh.length) { serverRefresh($r, refresh); }
            }
            if ($f.length) {
                $reg.trigger("cdchange", { id: id, key: $f.attr("data-k"), value: valueOf($f) });
            }
        }

        /* REFRESH_ON: run the Detail Query again for this card with the current values bound */
        function serverRefresh($r, keys) {
            var id = $r.attr("data-id"), s = (seq[id] || 0) + 1, f01 = [], f02 = [];
            seq[id] = s;
            fields($r).each(function () {
                f01.push($(this).attr("data-k"));
                f02.push(valueOf($(this)) || "");
            });
            $r.addClass("is-busy");
            return apex.server.plugin(o.ajaxId, {
                x01: "FIELDS", x02: id, x03: $r.attr("data-n"), x04: keys.join(","),
                f01: f01, f02: f02, pageItems: o.items || undefined
            }, { dataType: "json" }).done(function (d) {
                if (seq[id] !== s) { return; }                       /* a newer refresh is on its way */
                ((d && d.fields) || []).forEach(function (it) {
                    var $old = fld($r, it.k), $w = $old.closest(".cd-f"), $new, $nf, before = valueOf($old);
                    if (!$w.length) { return; }
                    $new = $(it.html);
                    $nf = $new.find("[data-k]").addBack("[data-k]").first();
                    if ($w.hasClass("is-off")) { $new.addClass("is-off").prop("hidden", true); }
                    $w.replaceWith($new);
                    setupField($nf);                                 /* shows the refreshed value */
                    $nf.attr("data-o", $old.attr("data-o"));         /* keep the stored value for change detection */
                    if (valueOf($nf) !== before) { afterChange($r, it.k, 1, true); }
                });
                applyConds($r);
                refreshNeed($r);
                updateCounts();
            }).fail(function (jq, status, err) {
                if (seq[id] !== s) { return; }
                apex.message.showErrors([{ type: "error", location: "page",
                    message: "Could not refresh " + keys.join(", ") + " for " + $r.attr("data-label") + ": " + (err || status) }]);
            }).always(function () {
                if (seq[id] === s) { $r.removeClass("is-busy"); }
            });
        }

        /* ---------------------------------------------------------------- list chrome */
        function updateCounts() {
            var $all = rows(), $vis = $all.not("[hidden]"), sel = $all.filter(".is-sel").length,
                $cb = $vis.find(".cd-sel"), n = $cb.filter(":checked").length;
            $root.find(".cd-count").text(($vis.length === $all.length ? $all.length : $vis.length + " of " + $all.length) +
                " " + plural($all.length) + (sel ? ", " + sel + " selected" : ""));
            $root.find(".cd-all-cb").prop("checked", $cb.length > 0 && n === $cb.length).prop("indeterminate", n > 0 && n < $cb.length);
            $root.find(".cd-chip-need .cd-n").text($all.filter(".is-need").length);
        }

        function toggle($r, open) {
            var $b = $r.find(".cd-body"), on = open === undefined ? $b.prop("hidden") : open;
            $b.prop("hidden", !on);
            $r.toggleClass("is-open", on).find(".cd-exp").attr("aria-expanded", String(on));
        }

        /* cards hidden by the search or a chip are unselected, so actions only touch what the user sees */
        function applyFilter() {
            var q = state.q.toLowerCase(), shown = 0;
            rows().each(function () {
                var $r = $(this),
                    ok = (!q || ($r.attr("data-search") || "").indexOf(q) >= 0) &&
                         (!state.f || (state.f === NEED ? $r.hasClass("is-need") : $r.attr("data-f") === state.f));
                $r.prop("hidden", !ok);
                if (ok) { shown++; } else { $r.removeClass("is-sel").find(".cd-sel").prop("checked", false); }
            });
            $root.find(".cd-noresult").prop("hidden", shown > 0);
            updateCounts();
        }

        function clearFilter() {
            state.q = "";
            state.f = "";
            $root.find(".cd-search").val("");
            $root.find(".cd-chip").removeClass("is-on").attr("aria-pressed", "false")
                .first().addClass("is-on").attr("aria-pressed", "true");
            applyFilter();
        }

        function buildChips() {
            var seen = {}, vals = [], $c = $root.find(".cd-chips");
            rows().each(function () {
                var f = $(this).attr("data-f");
                if (f && !seen[f]) { seen[f] = true; vals.push(f); }
            });
            if (vals.length > 1) {
                $c.append($('<button type="button" class="cd-chip is-on" data-f="" aria-pressed="true">').text("All"));
                vals.forEach(function (f) {
                    $c.append($('<button type="button" class="cd-chip" aria-pressed="false">').attr("data-f", f).text(f));
                });
            }
            if ($root.find(".cd-in").length && $root.find(".is-req, [data-req-when]").length) {
                if (!$c.children().length) {
                    $c.append($('<button type="button" class="cd-chip is-on" data-f="" aria-pressed="true">').text("All"));
                }
                $c.append($('<button type="button" class="cd-chip cd-chip-need" aria-pressed="false">Needs input <span class="cd-n"></span></button>'));
            }
        }

        /* ---------------------------------------------------------------- submit */
        /* number values are sent as JSON numbers written from the text, never through a JS number */
        function numToken(c) { return c === null ? null : "@@N@@" + norm(c) + "@@"; }

        function collect(errors) {
            var out = [];
            rows().each(function () {
                var $r = $(this), rec = null;
                fields($r).each(function () {
                    var $f = $(this), k = $f.attr("data-k"), t = $f.attr("data-t"), c = null;
                    if (!isShown($f)) { return; }                     /* hidden by SHOW_WHEN: not sent */
                    if (t === "NUMBER") {
                        c = isInput($f) ? fromInput($f.val()) : fromData($f.attr("data-v"));
                        if (c === BAD) {
                            errors.push(apex.util.escapeHTML(labelOf($f) + " for " + $r.attr("data-label") +
                                " is not a valid number. Use \"" + dec + "\" for decimals."));
                            $f.addClass("is-invalid");
                            toggle($r, true);
                            return;
                        }
                    }
                    if (!changed($f)) { return; }
                    rec = rec || { id: $r.attr("data-id"), version: $r.attr("data-version") || null };
                    rec[k] = t === "NUMBER" ? numToken(c) : valueOf($f);
                });
                if (rec) { out.push(rec); }
            });
            return out;
        }

        function selected() { return rows().filter(".is-sel"); }
        function ids($s) { return $s.map(function () { return $(this).attr("data-id"); }).get(); }

        /* ---------------------------------------------------------------- set up (again after a refresh) */
        function setupField($f) {
            if ($f.is("select")) { fillSelect($f, optionsOf($f)); }
            else if ($f.hasClass("cd-num")) { $f.val(show(fromData($f.attr("data-o")))); }
            else if (!isInput($f)) {
                var v = $f.attr("data-v");
                if (v && !$f.attr("data-d") && ($f.attr("data-lov") || $f.attr("data-lovj") || $f.attr("data-t") === "NUMBER")) {
                    setShown($f, v);
                }
            }
        }

        function setup() {
            $root = $reg.find(".cd").first();
            lovs = {};
            seq = {};
            state = { q: "", f: "" };
            try {
                JSON.parse($root.find("script.cd-lovs").text() || "[]").forEach(function (l) {
                    (lovs[l[0]] = lovs[l[0]] || []).push({ r: l[1], d: l[2], x: l[3], p: l[4] });
                });
            } catch (ex) {
                apex.debug.error("IGN Configurable Detail: the LOV Query DATA column is not valid JSON", ex);
            }
            rows().each(function () {
                var $r = $(this);
                /* parents first, so child lists can be filtered by them */
                fields($r).not("[data-lov-parent]").each(function () { setupField($(this)); });
                fields($r).filter("[data-lov-parent]").each(function () { setupField($(this)); });
                applyConds($r);
                refreshNeed($r);
            });
            buildChips();
            updateCounts();
        }

        /* o.items is the region's "Page Items to Submit" as a jQuery selector ("#P1_A,#P1_B") */
        function refresh() {
            return apex.server.plugin(o.ajaxId, { x01: "RELOAD", pageItems: o.items || undefined }, {
                dataType: "text",
                refreshObject: $reg,
                loadingIndicator: $root,
                loadingIndicatorPosition: "centered"
            }).done(function (html) {
                $root.replaceWith(html);
                setup();
                $reg.trigger("cdready");
            });
        }

        setup();

        $reg
            .on("change", ".cd-in", function () {
                var $f = $(this), $r = $f.closest(".cd-row");
                afterChange($r, $f.attr("data-k"));
                updateCounts();
            })
            .on("keydown", "input", function (e) {
                if (e.key === "Enter") { e.preventDefault(); }            /* Enter would submit the page */
            })
            .on("keydown", ".cd-num", function (e) {
                if (e.key === grp && grp === "." && !this.readOnly) {
                    e.preventDefault();                   /* "." is the thousands separator here */
                    if (e.code === "NumpadDecimal" && this.setRangeText) {
                        this.setRangeText(dec, this.selectionStart, this.selectionEnd, "end");
                        $(this).trigger("input");
                    }
                }
            })
            .on("blur", ".cd-num", function () {
                var c = fromInput($(this).val());
                $(this).toggleClass("is-invalid", c === BAD);
                if (c !== BAD) { $(this).val(show(c)); }
            })
            .on("click", ".cd-exp", function () { toggle($(this).closest(".cd-row")); })
            .on("click", ".cd-sum", function (e) {
                if ($(e.target).closest("input, select, textarea, button, label, a").length) { return; }
                toggle($(this).closest(".cd-row"));
            })
            .on("change", ".cd-sel", function () {
                $(this).closest(".cd-row").toggleClass("is-sel", this.checked);
                updateCounts();
            })
            .on("change", ".cd-all-cb", function () {
                var on = this.checked;
                rows().not("[hidden]").each(function () {
                    $(this).toggleClass("is-sel", on).find(".cd-sel").prop("checked", on);
                });
                updateCounts();
            })
            .on("input", ".cd-search", function () {
                state.q = $(this).val();
                applyFilter();
            })
            .on("click", ".cd-chip", function () {
                $root.find(".cd-chip").removeClass("is-on").attr("aria-pressed", "false");
                $(this).addClass("is-on").attr("aria-pressed", "true");
                state.f = $(this).hasClass("cd-chip-need") ? NEED : ($(this).attr("data-f") || "");
                applyFilter();
            })
            .on("click", ".cd-expand-all", function () {
                var $v = rows().not("[hidden]"), allOpen = $v.length && $v.filter(".is-open").length === $v.length;
                $v.each(function () { toggle($(this), !allOpen); });
                $(this).text(allOpen ? "Expand all" : "Collapse all");
            });

        /* ---------------------------------------------------------------- API */
        api = {
            type: "IgnConfigDetail",
            ids: function () { return ids(rows()); },
            selectedIds: function () { return ids(selected()); },
            row$: function (id) { return row(id); },
            getValue: function (id, key) { return getIn(row(id), key); },
            /* v in canonical form ("." decimals, YYYY-MM-DD dates); runs the same cascade as a user change */
            setValue: function (id, key, v, text) {
                var $r = row(id), $f = fld($r, key);
                if (!$f.length) { return; }
                put($f, v, text);
                afterChange($r, $f.attr("data-k"));
                updateCounts();
            },
            /* list: [{r, d, x}]; keeps the current value when it is still in the list */
            setOptions: function (id, key, list) {
                var $r = row(id), $f = fld($r, key);
                if ($f.is("select")) {
                    fillSelect($f, list || [], $f.val() || "");
                    applyConds($r);
                    refreshNeed($r);
                    updateCounts();
                }
            },
            /* the chosen option: {r, d, x} where x is the DATA object from the LOV query */
            getOption: function (id, key) {
                var $f = fld(row(id), key), v = valueOf($f), it;
                if (v === null) { return null; }
                if ($f.is("select")) {
                    it = $f.find("option:checked");
                    return { r: v, d: it.text(), x: it.data("x") || null };
                }
                it = optionFor(lovOf($f), v);
                return it ? { r: it.r, d: it.d, x: it.x || null } : { r: v, d: v, x: null };
            },
            setReadOnly: function (id, key, on) {
                var $f = fld(row(id), key);
                if ($f.is("select")) { $f.prop("disabled", on); } else { $f.prop("readOnly", on); }
                $f.toggleClass("is-auto", !!on);
            },
            setNote: function (id, key, text) { setNote(fld(row(id), key), text); },
            setBusy: function (id, on) { row(id).toggleClass("is-busy", !!on); },
            expand: function (id, open) { toggle(row(id), open); },
            missing: function (id) { return missing(row(id)); },
            /* re-runs the Detail Query for these keys of one card (as REFRESH_ON does) */
            refreshFields: function (id, keys) { return serverRefresh(row(id), [].concat(keys)); },
            /* reloads the cards from the server (unsaved changes are dropped); returns a promise */
            refresh: function () { return refresh(); },
            /*
             * Checks, fills the selection and edits items, then submits.
             * opts: request (page request), confirm (message), validate (check required fields
             * of the selected cards), verb (for messages), selection (false = no selection needed)
             */
            submit: function (opts) {
                var $s = selected(), errors = [], edits, json, $check;
                opts = opts || {};
                apex.message.clearErrors();
                if (opts.selection !== false && o.selItem && !$s.length) {
                    apex.message.alert("Select at least one " + noun + " to " + (opts.verb || "continue") + ".");
                    return false;
                }
                if (rows().filter(".is-busy").length) {
                    apex.message.alert("Some values are still loading. Try again in a moment.");
                    return false;
                }
                if (opts.validate) {
                    $check = o.selItem && opts.selection !== false ? $s : rows();
                    $check.each(function () {
                        var $r = $(this), m = missing($r);
                        if (m.length) {
                            errors.push(apex.util.escapeHTML(m.join(", ") + (m.length > 1 ? " are" : " is") +
                                " required for " + $r.attr("data-label") + "."));
                            toggle($r, true);
                        }
                    });
                }
                if (o.editsItem) { edits = collect(errors); }
                if (errors.length) {
                    clearFilter();
                    apex.message.showErrors(errors.map(function (m) {
                        return { type: "error", location: "page", message: m, unsafe: false };
                    }));
                    return false;
                }
                if (o.editsItem) {
                    json = JSON.stringify(edits).replace(/"@@N@@(-?\d+(?:\.\d+)?)@@"/g, "$1");
                    if (json.length > 32000) {
                        apex.message.alert("Too many " + plural(2) + " were changed to save at once. Save fewer at a time.");
                        return false;
                    }
                    apex.item(o.editsItem).setValue(edits.length ? json : "");
                }
                if (o.selItem) { apex.item(o.selItem).setValue(ids($s).join(";")); }
                if (opts.request) {
                    if (opts.confirm) { apex.page.confirm(opts.confirm, opts.request); }
                    else { apex.page.submit(opts.request); }
                }
                return true;
            }
        };
        apex.region.create(regionId, api);
        $reg.addClass("cd-ready").trigger("cdready");
    }

    window.ignConfigDetail = { init: init, parseCondition: parseCond, evalCondition: evalCond };
})(apex.jQuery);
