--------------------------------------------------------------------------------
-- IGN Configurable Detail: code behind the APEX region plugin COM.IGN.CONFIG_DETAIL
--
-- Run this script in the application's parsing schema BEFORE you import the
-- plugin. The plugin calls ign_config_detail.render and ign_config_detail.ajax
-- (APEX 24.1+ "Procedure" plugin interface). Pages call ign_config_detail.save_edits.
--
-- Everything the region shows comes from three SQL statements:
--   Main query    region Source (SQL)           one row per record (a card)
--   Detail query  plugin attribute, :PK bound   one row per field in the expanded card
--   LOV query     plugin attribute, run once    all option lists
-- See README.md and docs/REFERENCE.md of the repository for every column the queries can return.
--------------------------------------------------------------------------------
create or replace package ign_config_detail
as
    procedure render (
        p_plugin in            apex_plugin.t_plugin,
        p_region in            apex_plugin.t_region,
        p_param  in            apex_plugin.t_region_render_param,
        p_result in out nocopy apex_plugin.t_region_render_result );

    procedure ajax (
        p_plugin in            apex_plugin.t_plugin,
        p_region in            apex_plugin.t_region,
        p_param  in            apex_plugin.t_region_ajax_param,
        p_result in out nocopy apex_plugin.t_region_ajax_result );

    -- Applies the JSON the plugin writes into its Edits Item:
    --   [{"id":"<pk>","version":"<ROW_VERSION>","<item key>":<value>, ...}, ...]
    -- p_columns lists what may be written, either "COL_A,COL_B" (item key = column name)
    -- or "key=COLUMN,..." when the keys differ from the column names. Keys that are not
    -- listed are ignored. DATE values arrive as YYYY-MM-DD, numbers with "." decimals.
    -- p_version_expr  optional SQL expression on the table that must equal "version"
    --                 (the same expression as the ROW_VERSION column of the main query)
    -- p_where         optional extra condition, e.g. approval_status in ('IN QUEUE','REJECTED')
    -- Raises ORA-20002 when a row was changed by someone else or no longer matches p_where.
    -- Returns the number of rows updated.
    function save_edits (
        p_edits         in clob,
        p_table_name    in varchar2,
        p_pk_column     in varchar2,
        p_columns       in varchar2,
        p_version_expr  in varchar2 default null,
        p_where         in varchar2 default null,
        p_record_name   in varchar2 default 'Record' )
        return pls_integer;
end ign_config_detail;
/

create or replace package body ign_config_detail
as
    c_nls    constant varchar2(40) := 'NLS_NUMERIC_CHARACTERS=''.,''';
    c_iso    constant varchar2(10) := 'YYYY-MM-DD';
    -- suffixes of a column-mode Detail Query (<column>__TYPE and friends)
    c_field_sfx constant varchar2(400) :=
        ',GROUP,LABEL,DISPLAY,ITEM,TYPE,REQ,LOV,LOV_PARENT,SHOW_WHEN,REQUIRED_WHEN,READONLY_WHEN,SET_FROM,REFRESH_ON,HELP,NOTE,PLACEHOLDER,';

    -- one field: a row of the detail query, or an editable cell of the main query
    type t_field is record (
        key         varchar2(255),
        typ         varchar2(30),
        label       varchar2(4000),
        value       varchar2(32767),
        disp        varchar2(32767),
        req         boolean := false,
        lov         varchar2(32767),
        lov_parent  varchar2(255),
        show_when   varchar2(4000),
        req_when    varchar2(4000),
        ro_when     varchar2(4000),
        set_from    varchar2(255),
        refresh_on  varchar2(4000),
        help        varchar2(4000),
        note        varchar2(4000),
        placeholder varchar2(4000),
        grp         varchar2(4000) );
    type t_flist is table of t_field index by pls_integer;

    -- column positions of the detail query
    type t_dcols is record (
        grp pls_integer, lbl pls_integer, val pls_integer, disp pls_integer, key pls_integer,
        typ pls_integer, req pls_integer, lov pls_integer, lovp pls_integer, show pls_integer,
        reqw pls_integer, row_ pls_integer, setf pls_integer, refr pls_integer, help pls_integer,
        note pls_integer, ph pls_integer );

    -- a summary cell of the main query and its decoration columns
    type t_cell is record (
        name varchar2(255), pos pls_integer,
        sub pls_integer, badge pls_integer, prefix pls_integer, pill pls_integer, cls pls_integer,
        width pls_integer, disp pls_integer, item pls_integer, typ pls_integer, lov pls_integer,
        req pls_integer, lovp pls_integer, reqw pls_integer, row_ pls_integer, setf pls_integer,
        refr pls_integer, ph pls_integer );
    type t_cells is table of t_cell index by pls_integer;
    type t_names is table of varchar2(255) index by pls_integer;
    type t_ints  is table of pls_integer index by pls_integer;
    type t_map   is table of varchar2(32767) index by varchar2(255);

    -- the region settings
    type t_cfg is record (
        rid        varchar2(255),
        detail_sql varchar2(32767),
        lov_sql    varchar2(32767),
        pk_col     varchar2(255),
        filter_col varchar2(255),
        sel_item   varchar2(255),
        edits_item varchar2(255),
        search     varchar2(4000),
        noun       varchar2(255),
        dec_sep    varchar2(1),
        date_fmt   varchar2(100),
        expand     varchar2(30),
        no_data    varchar2(4000),
        source     varchar2(32767) );

    ----------------------------------------------------------------------------
    -- small helpers
    ----------------------------------------------------------------------------
    procedure p (s in varchar2)
    is
    begin
        if s is not null then
            sys.htp.prn(s);
        end if;
    end;

    function e (s in varchar2) return varchar2
    is
    begin
        return apex_escape.html(s);
    end;

    function a (s in varchar2) return varchar2
    is
    begin
        return apex_escape.html_attribute(s);
    end;

    -- optional attribute: ' name="value"' or nothing
    function att (p_name in varchar2, p_value in varchar2) return varchar2
    is
    begin
        return case when p_value is not null then ' ' || p_name || '="' || a(p_value) || '"' end;
    end;

    function js (s in varchar2) return varchar2
    is
    begin
        return case when s is null then 'null' else apex_escape.js_literal(s) end;
    end;

    function truthy (s in varchar2) return boolean
    is
    begin
        return upper(trim(s)) in ('Y', 'YES', 'TRUE', '1');
    end;

    function heading (p_name in varchar2) return varchar2
    is
    begin
        -- unquoted aliases come back upper case: SUPPLIER_NAME -> Supplier Name
        if p_name = upper(p_name) then
            return initcap(replace(p_name, '_', ' '));
        end if;
        return p_name;
    end;

    function cfg (p_region in apex_plugin.t_region) return t_cfg
    is
        l t_cfg;
    begin
        l.rid        := nvl(p_region.static_id, 'R' || p_region.id);
        l.detail_sql := p_region.attributes.get_varchar2('detail_query');
        l.lov_sql    := p_region.attributes.get_varchar2('lov_query');
        l.pk_col     := upper(trim(p_region.attributes.get_varchar2('pk_column')));
        l.filter_col := upper(trim(p_region.attributes.get_varchar2('filter_column')));
        l.sel_item   := p_region.attributes.get_varchar2('selection_item');
        l.edits_item := p_region.attributes.get_varchar2('edits_item');
        l.search     := nvl(p_region.attributes.get_varchar2('search_placeholder'), 'Search');
        l.noun       := nvl(p_region.attributes.get_varchar2('record_name'), 'record');
        l.dec_sep    := nvl(p_region.attributes.get_varchar2('decimal_separator'), ',');
        l.date_fmt   := nvl(p_region.attributes.get_varchar2('date_format'), 'DD-Mon-YYYY');
        l.expand     := nvl(p_region.attributes.get_varchar2('initial_state'), 'COLLAPSED');
        l.no_data    := p_region.no_data_found_message;
        l.source     := p_region.source;
        return l;
    end;

    ----------------------------------------------------------------------------
    -- reading query columns
    ----------------------------------------------------------------------------
    function col_pos (p_ctx in apex_exec.t_context, p_name in varchar2) return pls_integer
    is
    begin
        for i in 1 .. apex_exec.get_column_count(p_ctx) loop
            if upper(apex_exec.get_column(p_ctx, i).name) = p_name then
                return i;
            end if;
        end loop;
        return null;
    end;

    function is_date_col (p_ctx in apex_exec.t_context, p_pos in pls_integer) return boolean
    is
    begin
        return p_pos is not null
           and apex_exec.get_column(p_ctx, p_pos).data_type in (apex_exec.c_data_type_date, apex_exec.c_data_type_timestamp);
    end;

    -- any column as canonical text: numbers with "." decimals and full precision,
    -- dates as YYYY-MM-DD (with HH24:MI:SS when there is a time part)
    function val (p_ctx in apex_exec.t_context, p_pos in pls_integer) return varchar2
    is
        l_type apex_exec.t_data_type;
        l_d    date;
    begin
        if p_pos is null then
            return null;
        end if;
        l_type := apex_exec.get_column(p_ctx, p_pos).data_type;
        if l_type = apex_exec.c_data_type_number then
            return to_char(apex_exec.get_number(p_ctx, p_pos), 'TM9', c_nls);
        elsif l_type in (apex_exec.c_data_type_date, apex_exec.c_data_type_timestamp) then
            if l_type = apex_exec.c_data_type_date then
                l_d := apex_exec.get_date(p_ctx, p_pos);
            else
                l_d := cast(apex_exec.get_timestamp(p_ctx, p_pos) as date);
            end if;
            return case when l_d = trunc(l_d) then to_char(l_d, c_iso) else to_char(l_d, c_iso || ' HH24:MI:SS') end;
        elsif l_type = apex_exec.c_data_type_clob then
            return dbms_lob.substr(apex_exec.get_clob(p_ctx, p_pos), 32000, 1);
        end if;
        return apex_exec.get_varchar2(p_ctx, p_pos);
    end;

    -- what a read-only date shows when the query gives no DISPLAY_VALUE
    function date_text (p_ctx in apex_exec.t_context, p_pos in pls_integer, p_fmt in varchar2) return varchar2
    is
        l_v varchar2(30) := val(p_ctx, p_pos);
    begin
        if l_v is null then
            return null;
        end if;
        return to_char(to_date(l_v, case when length(l_v) > 10 then c_iso || ' HH24:MI:SS' else c_iso end),
                       p_fmt || case when length(l_v) > 10 then ' HH24:MI' end);
    end;

    function norm_type (p_type in varchar2, p_key in varchar2) return varchar2
    is
        l_type varchar2(30) := upper(trim(p_type));
    begin
        if l_type = 'SELECT' then
            l_type := 'LOV';
        elsif l_type in ('VIEW', 'VIEW_ONLY', 'READONLY', 'READ_ONLY') then
            l_type := 'DISPLAY';
        end if;
        if p_key is null and l_type <> 'HIDDEN' then
            return 'DISPLAY';                       -- nothing to send back without a key
        elsif l_type in ('LOV', 'TEXT', 'NUMBER', 'TEXTAREA', 'DATE', 'DISPLAY', 'HIDDEN') then
            return l_type;
        end if;
        return 'DISPLAY';
    end;

    ----------------------------------------------------------------------------
    -- HTML of one field
    ----------------------------------------------------------------------------
    -- attributes shared by inputs and read-only values
    function meta (f in t_field) return varchar2
    is
    begin
        return att('data-k', f.key)
            || ' data-t="' || f.typ || '"'
            || case when f.key is not null then ' data-o="' || a(f.value) || '"' end
            || case when f.req then ' data-req="Y"' end
            || att('data-req-when', f.req_when)
            || att('data-ro-when', f.ro_when)
            || case
                   when substr(ltrim(f.lov), 1, 1) = '[' then att('data-lovj', f.lov)
                   else att('data-lov', f.lov)
               end
            || att('data-lov-parent', f.lov_parent)
            || att('data-set-from', f.set_from)
            || att('data-refresh-on', f.refresh_on);
    end;

    function input_html (p_id in varchar2, f in t_field, p_aria in varchar2 default null) return varchar2
    is
        l_common varchar2(32767);
    begin
        l_common := ' id="' || a(p_id) || '"' || meta(f)
                 || case when f.req then ' aria-required="true"' end
                 || att('aria-label', p_aria)
                 || att('placeholder', f.placeholder);
        if f.typ = 'LOV' then
            return '<select class="cd-in"' || l_common || att('data-d', f.disp)
                || '><option value="">' || e(nvl(f.placeholder, '- Select -')) || '</option>'
                || case when f.value is not null then
                       '<option value="' || a(f.value) || '" selected>' || e(nvl(f.disp, f.value)) || '</option>' end
                || '</select>';
        elsif f.typ = 'NUMBER' then
            return '<input type="text" inputmode="decimal" autocomplete="off" class="cd-in cd-num"' || l_common || '>';
        elsif f.typ = 'TEXTAREA' then
            return '<textarea class="cd-in" rows="2"' || l_common || '>' || e(f.value) || '</textarea>';
        elsif f.typ = 'DATE' then
            return '<input type="date" class="cd-in"' || l_common || ' value="' || a(substr(f.value, 1, 10)) || '">';
        end if;
        return '<input type="text" autocomplete="off" class="cd-in"' || l_common || ' value="' || a(f.value) || '">';
    end;

    -- read-only value; with a key it can still change (SET_FROM, REFRESH_ON, JavaScript) and is sent back
    function show_html (f in t_field) return varchar2
    is
        l_text varchar2(32767) := nvl(f.disp, f.value);
    begin
        return '<span class="cd-v' || case when l_text is null then ' cd-empty' end || '"'
            || meta(f)
            || case when f.key is not null then ' data-v="' || a(f.value) || '"' end
            || att('data-d', f.disp)
            || '>' || nvl(e(l_text), '&mdash;') || '</span>';
    end;

    -- one row of the expanded part, wrapper included
    function field_html (p_id in varchar2, f in t_field) return varchar2
    is
        l_input boolean := f.typ in ('LOV', 'TEXT', 'NUMBER', 'TEXTAREA', 'DATE');
    begin
        if f.typ = 'HIDDEN' then
            return '<div class="cd-f cd-hidden" hidden' || att('data-fk', f.key) || '>' || show_html(f) || '</div>';
        end if;
        return '<div class="cd-f' || case when f.req then ' is-req' end || '"'
            || att('data-fk', f.key) || att('data-show-when', f.show_when) || '>'
            || case
                   when l_input then '<label class="cd-l" for="' || a(p_id) || '">' || e(f.label) || '</label>'
                   else '<span class="cd-l">' || e(f.label) || '</span>'
               end
            || '<div class="cd-fv">'
            || case when l_input then input_html(p_id, f) else show_html(f) end
            || case when f.help is not null then '<p class="cd-help">' || e(f.help) || '</p>' end
            || '<p class="cd-note" role="status"' || case when f.note is null then ' hidden' end || '>' || e(f.note) || '</p>'
            || '</div></div>';
    end;

    function field_id (p_rid in varchar2, p_n in pls_integer, f in t_field, p_i in pls_integer) return varchar2
    is
    begin
        return p_rid || '_' || p_n || '_' || nvl(regexp_replace(lower(f.key), '[^a-z0-9_]', '_'), 'f' || p_i);
    end;

    ----------------------------------------------------------------------------
    -- detail query
    ----------------------------------------------------------------------------
    -- Bind variables of a query, each name once, upper case. String literals (also q'[...]')
    -- and comments are skipped, so 'HH24:MI' is not taken for a bind.
    function bind_names (p_sql in varchar2) return apex_t_varchar2
    is
        l_sql   varchar2(32767) := p_sql;
        l_names apex_t_varchar2 := apex_t_varchar2();
        l_name  varchar2(255);
        l_i     pls_integer := 1;
    begin
        l_sql := regexp_replace(l_sql, '/\*.*?\*/', ' ', 1, 0, 'n');
        l_sql := regexp_replace(l_sql, '--[^' || chr(10) || ']*', ' ');
        l_sql := regexp_replace(l_sql, '[qQ]''\[.*?\]''|[qQ]''\{.*?\}''|[qQ]''\(.*?\)''|[qQ]''<.*?>''|[qQ]''!.*?!''', ' ', 1, 0, 'n');
        l_sql := regexp_replace(l_sql, '''[^'']*''', ' ');
        loop
            l_name := upper(regexp_substr(l_sql, ':([A-Za-z][A-Za-z0-9_$#]*)', 1, l_i, null, 1));
            exit when l_name is null;
            if l_name not member of l_names then
                l_names.extend;
                l_names(l_names.count) := l_name;
            end if;
            l_i := l_i + 1;
        end loop;
        return l_names;
    end;

    -- Binds every bind variable the query uses, and only those:
    --   :PK          the record key (detail query)
    --   :CD_REFRESH  'Y' on a REFRESH_ON round trip, else 'N'
    --   :<ITEM_KEY>  on a refresh, the current value of that field (else null)
    --   anything else from session state (page items, :APP_USER, ...)
    function params (
        p_sql     in varchar2,
        p_pk      in varchar2,
        p_values  in t_map,
        p_refresh in boolean default false )
        return apex_exec.t_parameters
    is
        l_params apex_exec.t_parameters;
        l_names  apex_t_varchar2 := bind_names(p_sql);
        l_value  varchar2(32767);
    begin
        for i in 1 .. l_names.count loop
            if l_names(i) = 'PK' then
                l_value := p_pk;
            elsif l_names(i) = 'CD_REFRESH' then
                l_value := case when p_refresh then 'Y' else 'N' end;
            elsif p_values.exists(lower(l_names(i))) then
                l_value := p_values(lower(l_names(i)));
            else
                l_value := v(l_names(i));
            end if;
            apex_exec.add_parameter(l_params, l_names(i), l_value);
        end loop;
        return l_params;
    end;

    function open_detail (
        p_sql     in varchar2,
        p_pk      in varchar2,
        p_values  in t_map,
        p_refresh in boolean default false )
        return apex_exec.t_context
    is
    begin
        return apex_exec.open_query_context(
                   p_location       => apex_exec.c_location_local_db,
                   p_sql_query      => p_sql,
                   p_sql_parameters => params(p_sql, p_pk, p_values, p_refresh) );
    end;

    function detail_cols (p_ctx in apex_exec.t_context) return t_dcols
    is
        c t_dcols;
    begin
        c.grp  := col_pos(p_ctx, 'GROUP_NAME');
        c.lbl  := col_pos(p_ctx, 'LABEL');
        c.val  := col_pos(p_ctx, 'VALUE');
        c.disp := col_pos(p_ctx, 'DISPLAY_VALUE');
        c.key  := col_pos(p_ctx, 'ITEM_KEY');
        c.typ  := col_pos(p_ctx, 'ITEM_TYPE');
        c.req  := col_pos(p_ctx, 'IS_REQUIRED');
        c.lov  := col_pos(p_ctx, 'LOV');
        c.lovp := col_pos(p_ctx, 'LOV_PARENT');
        c.show := col_pos(p_ctx, 'SHOW_WHEN');
        c.reqw := col_pos(p_ctx, 'REQUIRED_WHEN');
        c.row_ := col_pos(p_ctx, 'READONLY_WHEN');
        c.setf := col_pos(p_ctx, 'SET_FROM');
        c.refr := col_pos(p_ctx, 'REFRESH_ON');
        c.help := col_pos(p_ctx, 'HELP_TEXT');
        c.note := col_pos(p_ctx, 'NOTE');
        c.ph   := col_pos(p_ctx, 'PLACEHOLDER');
        return c;
    end;

    function detail_field (p_ctx in apex_exec.t_context, c in t_dcols, p_date_fmt in varchar2) return t_field
    is
        f t_field;
    begin
        f.key         := trim(val(p_ctx, c.key));
        f.typ         := norm_type(val(p_ctx, c.typ), f.key);
        f.label       := val(p_ctx, c.lbl);
        f.value       := val(p_ctx, c.val);
        f.disp        := val(p_ctx, c.disp);
        f.req         := truthy(val(p_ctx, c.req));
        f.lov         := val(p_ctx, c.lov);
        f.lov_parent  := trim(val(p_ctx, c.lovp));
        f.show_when   := val(p_ctx, c.show);
        f.req_when    := val(p_ctx, c.reqw);
        f.ro_when     := val(p_ctx, c.row_);
        f.set_from    := trim(val(p_ctx, c.setf));
        f.refresh_on  := lower(replace(val(p_ctx, c.refr), ' '));
        f.help        := val(p_ctx, c.help);
        f.note        := val(p_ctx, c.note);
        f.placeholder := val(p_ctx, c.ph);
        if f.disp is null and f.typ <> 'DATE' and is_date_col(p_ctx, c.val) then
            f.disp := date_text(p_ctx, c.val, p_date_fmt);
        end if;
        return f;
    end;

    -- Two ways to write the Detail Query:
    --   row mode     (has LABEL and VALUE columns)  one row per field
    --   column mode  (any other query)              first row only, one field per column;
    --                <col>__TYPE, __LOV, __REQ, __GROUP, __LABEL, ... configure that column
    function column_fields (p_ctx in apex_exec.t_context, p_date_fmt in varchar2) return t_flist
    is
        type t_pos is table of pls_integer index by varchar2(400);
        l_list  t_flist;
        l_pos   t_pos;
        l_names t_names;
        l_up    varchar2(255);
        l_at    pls_integer;
        l_empty t_field;
        f       t_field;
        function s (p_base in varchar2, p_sfx in varchar2) return varchar2 is
        begin
            if l_pos.exists(p_base || '|' || p_sfx) then
                return val(p_ctx, l_pos(p_base || '|' || p_sfx));
            end if;
            return null;
        end;
        function is_sfx (p_up in varchar2) return boolean is
        begin
            l_at := instr(p_up, '__');
            return l_at > 1 and instr(c_field_sfx, ',' || substr(p_up, l_at + 2) || ',') > 0;
        end;
    begin
        for i in 1 .. apex_exec.get_column_count(p_ctx) loop
            l_names(i) := apex_exec.get_column(p_ctx, i).name;
            l_up := upper(l_names(i));
            if is_sfx(l_up) then
                l_pos(substr(l_up, 1, l_at - 1) || '|' || substr(l_up, l_at + 2)) := i;
            end if;
        end loop;
        if not apex_exec.next_row(p_ctx) then
            return l_list;
        end if;
        for i in 1 .. l_names.count loop
            l_up := upper(l_names(i));
            if not is_sfx(l_up) then
                f := l_empty;
                f.grp         := s(l_up, 'GROUP');
                f.label       := nvl(s(l_up, 'LABEL'), heading(l_names(i)));
                f.value       := val(p_ctx, i);
                f.disp        := s(l_up, 'DISPLAY');
                f.lov         := s(l_up, 'LOV');
                f.key         := nvl(trim(s(l_up, 'ITEM')), lower(regexp_replace(l_names(i), '[^A-Za-z0-9_]', '_')));
                f.typ         := norm_type(nvl(s(l_up, 'TYPE'), 'DISPLAY'), f.key);
                f.req         := truthy(s(l_up, 'REQ'));
                f.lov_parent  := trim(s(l_up, 'LOV_PARENT'));
                f.show_when   := s(l_up, 'SHOW_WHEN');
                f.req_when    := s(l_up, 'REQUIRED_WHEN');
                f.ro_when     := s(l_up, 'READONLY_WHEN');
                f.set_from    := trim(s(l_up, 'SET_FROM'));
                f.refresh_on  := lower(replace(s(l_up, 'REFRESH_ON'), ' '));
                f.help        := s(l_up, 'HELP');
                f.note        := s(l_up, 'NOTE');
                f.placeholder := s(l_up, 'PLACEHOLDER');
                if f.disp is null and f.typ <> 'DATE' and is_date_col(p_ctx, i) then
                    f.disp := date_text(p_ctx, i, p_date_fmt);
                end if;
                l_list(l_list.count + 1) := f;
            end if;
        end loop;
        return l_list;
    end;

    function read_fields (
        p_sql      in varchar2,
        p_pk       in varchar2,
        p_values   in t_map,
        p_refresh  in boolean,
        p_date_fmt in varchar2 )
        return t_flist
    is
        l_ctx  apex_exec.t_context;
        l_list t_flist;
        c      t_dcols;
    begin
        l_ctx := open_detail(p_sql, p_pk, p_values, p_refresh);
        c := detail_cols(l_ctx);
        if c.lbl is not null and c.val is not null then
            while apex_exec.next_row(l_ctx) loop
                l_list(l_list.count + 1) := detail_field(l_ctx, c, p_date_fmt);
                l_list(l_list.count).grp := val(l_ctx, c.grp);
            end loop;
        else
            l_list := column_fields(l_ctx, p_date_fmt);
        end if;
        apex_exec.close(l_ctx);
        return l_list;
    exception
        when others then
            apex_exec.close(l_ctx);
            raise;
    end;

    procedure detail (
        p_cfg in t_cfg,
        p_pk  in varchar2,
        p_n   in pls_integer )
    is
        l_none   t_map;
        l_list   t_flist;
        l_group  varchar2(4000);
        l_open   boolean := false;
    begin
        l_list := read_fields(p_cfg.detail_sql, p_pk, l_none, false, p_cfg.date_fmt);
        p('<div class="cd-groups">');
        for i in 1 .. l_list.count loop
            if not l_open or nvl(l_list(i).grp, '~') <> nvl(l_group, '~') then
                if l_open then
                    p('</section>');
                end if;
                l_group := l_list(i).grp;
                p('<section class="cd-group">' || case when l_group is not null then '<h3>' || e(l_group) || '</h3>' end);
                l_open := true;
            end if;
            p(field_html(field_id(p_cfg.rid, p_n, l_list(i), i), l_list(i)));
        end loop;
        if l_open then
            p('</section>');
        end if;
        p('</div>');
    end;

    ----------------------------------------------------------------------------
    -- LOV query: [[name, return, display, data, parent], ...]
    ----------------------------------------------------------------------------
    procedure lovs (p_sql in varchar2)
    is
        l_none  t_map;
        l_ctx   apex_exec.t_context;
        c_name  pls_integer;  c_r pls_integer;  c_d pls_integer;  c_x pls_integer;  c_p pls_integer;
        l_first boolean := true;
        l_x     varchar2(32767);
        function j (s in varchar2) return varchar2 is
        begin
            return case when s is null then 'null' else '"' || replace(apex_escape.json(s), '<', '<') || '"' end;
        end;
    begin
        l_ctx  := apex_exec.open_query_context(
                      p_location       => apex_exec.c_location_local_db,
                      p_sql_query      => p_sql,
                      p_sql_parameters => params(p_sql, null, l_none) );
        c_name := col_pos(l_ctx, 'LOV_NAME');
        c_r    := col_pos(l_ctx, 'RETURN_VALUE');
        c_d    := col_pos(l_ctx, 'DISPLAY_VALUE');
        c_x    := col_pos(l_ctx, 'DATA');
        c_p    := col_pos(l_ctx, 'PARENT_VALUE');
        if c_name is null or c_r is null or c_d is null then
            raise_application_error(-20001, 'IGN Configurable Detail: the LOV Query needs the columns LOV_NAME, RETURN_VALUE and DISPLAY_VALUE.');
        end if;
        p('<script type="application/json" class="cd-lovs">[');
        while apex_exec.next_row(l_ctx) loop
            l_x := trim(val(l_ctx, c_x));
            p(case when not l_first then ',' end
              || '[' || j(val(l_ctx, c_name)) || ',' || j(val(l_ctx, c_r)) || ',' || j(val(l_ctx, c_d)) || ','
              || case when l_x is null then 'null' else replace(l_x, '<', '<') end || ','
              || j(val(l_ctx, c_p)) || ']');
            l_first := false;
        end loop;
        p(']</script>');
        apex_exec.close(l_ctx);
    exception
        when others then
            apex_exec.close(l_ctx);
            raise;
    end;

    ----------------------------------------------------------------------------
    -- the whole region (first render and refresh)
    ----------------------------------------------------------------------------
    procedure region_html (p_cfg in t_cfg)
    is
        l_ctx         apex_exec.t_context;
        l_cells       t_cells;
        l_data        t_ints;
        l_names       t_names;
        l_pk_pos      pls_integer;
        l_ver_pos     pls_integer;
        l_lbl_pos     pls_integer;
        l_srch_pos    pls_integer;
        l_filt_pos    pls_integer;
        l_up          varchar2(255);
        l_base        varchar2(255);
        l_sfx         varchar2(30);
        l_n           pls_integer := 0;
        l_pk          varchar2(4000);
        l_text        varchar2(32767);
        l_search_txt  varchar2(32767);
        l_cols        varchar2(4000);
        l_pill        varchar2(30);
        l_open        boolean;
        f             t_field;
        l_empty       t_field;
        l_none        t_map;
        c_suffixes    constant varchar2(400) :=
            ',SUB,BADGE,PREFIX,PILL,CLASS,WIDTH,DISPLAY,ITEM,TYPE,LOV,REQ,LOV_PARENT,REQUIRED_WHEN,READONLY_WHEN,SET_FROM,REFRESH_ON,PLACEHOLDER,';

        function sfx_of (p_up in varchar2) return varchar2 is
            l_at pls_integer := instr(p_up, '__');
        begin
            -- "Amount__PREFIX" -> PREFIX, "Rate__READONLY_WHEN" -> READONLY_WHEN (first "__" splits)
            if l_at > 1 and instr(c_suffixes, ',' || substr(p_up, l_at + 2) || ',') > 0 then
                return substr(p_up, l_at + 2);
            end if;
            return null;
        end;
    begin
        -- region Source; honours the region's Location (local, REST enabled SQL, REST source)
        l_ctx := apex_exec.open_query_context(
                     p_sql_parameters => params(p_cfg.source, null, l_none),
                     p_first_row      => 1 );

        -- 1. sort the columns into cells, decorations and special columns
        for i in 1 .. apex_exec.get_column_count(l_ctx) loop
            l_names(i) := apex_exec.get_column(l_ctx, i).name;
            l_up := upper(l_names(i));
            if l_up = p_cfg.filter_col then
                l_filt_pos := i;
            end if;
            if sfx_of(l_up) is not null then
                null;                                       -- attached in step 2
            elsif l_up = p_cfg.pk_col then
                l_pk_pos := i;
            elsif l_up = 'ROW_VERSION' then
                l_ver_pos := i;
            elsif l_up = 'ROW_LABEL' then
                l_lbl_pos := i;
            elsif l_up = 'SEARCH_TEXT' then
                l_srch_pos := i;
            elsif l_up like 'DATA\_%' escape '\' then
                l_data(l_data.count + 1) := i;
            elsif l_up <> nvl(p_cfg.filter_col, '~') then
                l_cells(l_cells.count + 1).name := l_names(i);
                l_cells(l_cells.count).pos := i;
            end if;
        end loop;

        if l_pk_pos is null then
            raise_application_error(-20001, 'IGN Configurable Detail: the region query has no column named '
                || nvl(p_cfg.pk_col, '(set the Primary Key Column attribute)') || '.');
        end if;

        -- 2. decorations: <cell>__SUB and friends
        for i in 1 .. l_names.count loop
            l_up  := upper(l_names(i));
            l_sfx := sfx_of(l_up);
            if l_sfx is not null then
                l_base := substr(l_up, 1, instr(l_up, '__') - 1);
                for c in 1 .. l_cells.count loop
                    if upper(l_cells(c).name) = l_base then
                        case l_sfx
                            when 'SUB'           then l_cells(c).sub    := i;
                            when 'BADGE'         then l_cells(c).badge  := i;
                            when 'PREFIX'        then l_cells(c).prefix := i;
                            when 'PILL'          then l_cells(c).pill   := i;
                            when 'CLASS'         then l_cells(c).cls    := i;
                            when 'WIDTH'         then l_cells(c).width  := i;
                            when 'DISPLAY'       then l_cells(c).disp   := i;
                            when 'ITEM'          then l_cells(c).item   := i;
                            when 'TYPE'          then l_cells(c).typ    := i;
                            when 'LOV'           then l_cells(c).lov    := i;
                            when 'REQ'           then l_cells(c).req    := i;
                            when 'LOV_PARENT'    then l_cells(c).lovp   := i;
                            when 'REQUIRED_WHEN' then l_cells(c).reqw   := i;
                            when 'READONLY_WHEN' then l_cells(c).row_   := i;
                            when 'SET_FROM'      then l_cells(c).setf   := i;
                            when 'REFRESH_ON'    then l_cells(c).refr   := i;
                            when 'PLACEHOLDER'   then l_cells(c).ph     := i;
                        end case;
                    end if;
                end loop;
            end if;
        end loop;

        p('<div class="cd" id="' || a(p_cfg.rid) || '_cd" data-sel="' || case when p_cfg.sel_item is not null then 'Y' else 'N' end || '">');

        -- 3. one card per row
        while apex_exec.next_row(l_ctx) loop
            l_n := l_n + 1;

            if l_n = 1 then
                l_cols := case when p_cfg.sel_item is not null then '20px ' end || '24px';
                for c in 1 .. l_cells.count loop
                    l_cols := l_cols || ' ' || nvl(val(l_ctx, l_cells(c).width), 'minmax(120px,1fr)');
                end loop;
                p('<div class="cd-bar">'
                  || case when p_cfg.sel_item is not null then
                         '<label class="cd-all"><input type="checkbox" class="cd-all-cb"> <span>Select all</span></label>' end
                  || '<span class="cd-count" aria-live="polite"></span>'
                  || '<input type="search" class="cd-search" placeholder="' || a(p_cfg.search) || '" aria-label="' || a(p_cfg.search) || '">'
                  || '<div class="cd-chips" role="group" aria-label="Filter"></div>'
                  || '<button type="button" class="cd-link-btn cd-expand-all">Expand all</button>'
                  || '</div>');
                p('<div class="cd-list" style="--cd-cols:' || a(l_cols) || '">'
                  || '<div class="cd-head" aria-hidden="true">'
                  || case when p_cfg.sel_item is not null then '<span></span>' end || '<span></span>');
                for c in 1 .. l_cells.count loop
                    p('<span class="' || a(val(l_ctx, l_cells(c).cls)) || '">' || e(heading(l_cells(c).name)) || '</span>');
                end loop;
                p('</div>');
            end if;

            l_pk := val(l_ctx, l_pk_pos);
            l_open := p_cfg.expand = 'EXPANDED' or (p_cfg.expand = 'FIRST' and l_n = 1);
            l_search_txt := val(l_ctx, l_srch_pos);
            if l_srch_pos is null then
                for c in 1 .. l_cells.count loop
                    l_search_txt := substr(l_search_txt || ' ' || nvl(val(l_ctx, l_cells(c).disp), val(l_ctx, l_cells(c).pos))
                                    || ' ' || val(l_ctx, l_cells(c).sub) || ' ' || val(l_ctx, l_cells(c).badge)
                                    || ' ' || val(l_ctx, l_cells(c).prefix), 1, 4000);
                end loop;
            end if;

            p('<article class="cd-row' || case when l_open then ' is-open' end || '" data-id="' || a(l_pk) || '" data-n="' || l_n || '"'
              || ' data-version="' || a(val(l_ctx, l_ver_pos)) || '"'
              || ' data-label="' || a(nvl(val(l_ctx, l_lbl_pos), l_pk)) || '"'
              || ' data-f="' || a(val(l_ctx, l_filt_pos)) || '"'
              || ' data-search="' || a(lower(l_search_txt)) || '"');
            for d in 1 .. l_data.count loop
                p(' data-' || lower(replace(substr(l_names(l_data(d)), 6), '_', '-')) || '="' || a(val(l_ctx, l_data(d))) || '"');
            end loop;
            p('>');

            -- summary line
            p('<div class="cd-sum">'
              || case when p_cfg.sel_item is not null then
                     '<input type="checkbox" class="cd-sel" aria-label="Select ' || a(nvl(val(l_ctx, l_lbl_pos), l_pk)) || '">' end
              || '<button type="button" class="cd-exp" aria-expanded="' || case when l_open then 'true' else 'false' end
              || '" aria-controls="' || a(p_cfg.rid) || '_b' || l_n || '"'
              || ' title="Show details"><span aria-hidden="true">&#9656;</span><span class="u-VisuallyHidden">Show details</span></button>');
            for c in 1 .. l_cells.count loop
                f := l_empty;
                f.key         := trim(val(l_ctx, l_cells(c).item));
                f.lov         := val(l_ctx, l_cells(c).lov);
                f.typ         := norm_type(nvl(val(l_ctx, l_cells(c).typ), case when f.lov is not null then 'LOV' else 'TEXT' end), f.key);
                f.value       := val(l_ctx, l_cells(c).pos);
                f.disp        := val(l_ctx, l_cells(c).disp);
                f.req         := truthy(val(l_ctx, l_cells(c).req));
                f.lov_parent  := trim(val(l_ctx, l_cells(c).lovp));
                f.req_when    := val(l_ctx, l_cells(c).reqw);
                f.ro_when     := val(l_ctx, l_cells(c).row_);
                f.set_from    := trim(val(l_ctx, l_cells(c).setf));
                f.refresh_on  := lower(replace(val(l_ctx, l_cells(c).refr), ' '));
                f.placeholder := val(l_ctx, l_cells(c).ph);
                if f.key is null and f.disp is null and is_date_col(l_ctx, l_cells(c).pos) then
                    f.disp := date_text(l_ctx, l_cells(c).pos, p_cfg.date_fmt);
                end if;
                l_pill := lower(val(l_ctx, l_cells(c).pill));

                p('<div class="cd-c ' || a(val(l_ctx, l_cells(c).cls)) || case when l_cells(c).pill is not null then ' cd-c-pill' end
                  || case when f.req then ' is-req' end || '"' || att('data-fk', f.key) || '>');
                l_text := val(l_ctx, l_cells(c).prefix);
                if l_text is not null then
                    p('<span class="cd-prefix">' || e(l_text) || '</span>');
                end if;
                if f.typ in ('LOV', 'TEXT', 'NUMBER', 'TEXTAREA', 'DATE') then
                    p(input_html(field_id(p_cfg.rid, l_n, f, -c), f, heading(l_cells(c).name)));
                elsif l_cells(c).pill is not null and f.key is null then
                    l_text := nvl(f.disp, f.value);
                    if l_text is not null then
                        p('<span class="cd-pill cd-tone-' || a(nvl(l_pill, 'neutral')) || '">' || e(l_text) || '</span>');
                    end if;
                else
                    p(show_html(f));
                end if;
                l_text := val(l_ctx, l_cells(c).badge);
                if l_text is not null then
                    p('<span class="cd-badge">' || e(l_text) || '</span>');
                end if;
                l_text := val(l_ctx, l_cells(c).sub);
                if l_text is not null then
                    p('<div class="cd-sub" title="' || a(l_text) || '">' || e(l_text) || '</div>');
                end if;
                p('</div>');
            end loop;
            p('</div>');

            -- expanded part
            p('<div class="cd-body" id="' || a(p_cfg.rid) || '_b' || l_n || '"' || case when not l_open then ' hidden' end || '>');
            if p_cfg.detail_sql is not null then
                detail(p_cfg, l_pk, l_n);
            end if;
            p('</div></article>');
        end loop;
        apex_exec.close(l_ctx);

        if l_n = 0 then
            p('<div class="cd-none">' || e(nvl(p_cfg.no_data, 'No ' || p_cfg.noun || 's to show.')) || '</div>');
        else
            p('</div><div class="cd-noresult" hidden>No ' || e(p_cfg.noun) || 's match the search.</div>');
        end if;
        if p_cfg.lov_sql is not null and l_n > 0 then
            lovs(p_cfg.lov_sql);
        end if;
        p('</div>');
    exception
        when others then
            apex_exec.close(l_ctx);
            raise;
    end;

    ----------------------------------------------------------------------------
    -- plugin entry points
    ----------------------------------------------------------------------------
    procedure render (
        p_plugin in            apex_plugin.t_plugin,
        p_region in            apex_plugin.t_region,
        p_param  in            apex_plugin.t_region_render_param,
        p_result in out nocopy apex_plugin.t_region_render_result )
    is
        l_cfg t_cfg := cfg(p_region);
    begin
        p('<div class="cd-wrap" id="' || a(l_cfg.rid) || '_wrap">');
        region_html(l_cfg);
        p('</div>');
        apex_javascript.add_onload_code(
            p_code => 'ignConfigDetail.init(' || js(l_cfg.rid) || ',{'
                   || 'ajaxId:' || js(apex_plugin.get_ajax_identifier)
                   || ',items:' || js(apex_plugin_util.page_item_names_to_jquery(p_region.ajax_items_to_submit))
                   || ',selItem:' || js(l_cfg.sel_item)
                   || ',editsItem:' || js(l_cfg.edits_item)
                   || ',dec:' || js(l_cfg.dec_sep)
                   || ',noun:' || js(l_cfg.noun) || '});' );
    end render;

    -- x01 = RELOAD    whole region again (apex.region(id).refresh())
    -- x01 = FIELDS    re-run the Detail Query for one card: x02 = pk, x03 = card number,
    --                 x04 = keys to return (comma separated), f01/f02 = keys/current values
    procedure ajax (
        p_plugin in            apex_plugin.t_plugin,
        p_region in            apex_plugin.t_region,
        p_param  in            apex_plugin.t_region_ajax_param,
        p_result in out nocopy apex_plugin.t_region_ajax_result )
    is
        l_cfg    t_cfg := cfg(p_region);
        l_values t_map;
        l_want   varchar2(32767) := ',' || lower(replace(apex_application.g_x04, ' ')) || ',';
        l_list   t_flist;
    begin
        if apex_application.g_x01 = 'FIELDS' then
            if l_cfg.detail_sql is null then
                raise_application_error(-20001, 'IGN Configurable Detail: no Detail Query.');
            end if;
            for i in 1 .. apex_application.g_f01.count loop
                l_values(lower(apex_application.g_f01(i))) :=
                    case when apex_application.g_f02.exists(i) then apex_application.g_f02(i) end;
            end loop;
            l_list := read_fields(l_cfg.detail_sql, apex_application.g_x02, l_values, true, l_cfg.date_fmt);
            apex_json.open_object;
            apex_json.open_array('fields');
            for i in 1 .. l_list.count loop
                if l_list(i).key is not null and instr(l_want, ',' || lower(l_list(i).key) || ',') > 0 then
                    apex_json.open_object;
                    apex_json.write('k', l_list(i).key);
                    apex_json.write('html', field_html(field_id(l_cfg.rid, to_number(apex_application.g_x03), l_list(i), i), l_list(i)));
                    apex_json.close_object;
                end if;
            end loop;
            apex_json.close_array;
            apex_json.close_object;
        else
            region_html(l_cfg);
        end if;
    end ajax;

    ----------------------------------------------------------------------------
    -- generic save
    ----------------------------------------------------------------------------
    function save_edits (
        p_edits         in clob,
        p_table_name    in varchar2,
        p_pk_column     in varchar2,
        p_columns       in varchar2,
        p_version_expr  in varchar2 default null,
        p_where         in varchar2 default null,
        p_record_name   in varchar2 default 'Record' )
        return pls_integer
    is
        l_table   varchar2(400) := dbms_assert.sql_object_name(p_table_name);
        l_pk      varchar2(128) := dbms_assert.simple_sql_name(p_pk_column);
        l_owner   varchar2(128);
        l_name    varchar2(128);
        l_map     t_map;                       -- item key (lower) -> column (upper)
        l_types   t_map;                       -- column -> data type
        l_arr     json_array_t;
        l_obj     json_object_t;
        l_keys    json_key_list;
        l_sql     varchar2(32767);
        l_set     varchar2(32767);
        l_vals    apex_t_varchar2;
        l_cur     integer;
        l_rows    integer;
        l_count   pls_integer := 0;
        l_col     varchar2(128);
        l_id      varchar2(4000);
        l_ver     varchar2(4000);

        function str (p_o in json_object_t, p_key in varchar2) return varchar2 is
            l_el json_element_t;
        begin
            if not p_o.has(p_key) then
                return null;
            end if;
            l_el := p_o.get(p_key);
            if l_el is null or l_el.is_null then
                return null;
            elsif l_el.is_string then
                return p_o.get_string(p_key);
            end if;
            return l_el.to_string;               -- numbers and booleans as written
        end;

    begin
        if p_edits is null or dbms_lob.getlength(p_edits) = 0 then
            return 0;
        end if;

        -- allowed columns
        for r in (select trim(column_value) entry from table(apex_string.split(p_columns, ',')) where trim(column_value) is not null) loop
            if instr(r.entry, '=') > 0 then
                l_map(lower(trim(substr(r.entry, 1, instr(r.entry, '=') - 1)))) :=
                    upper(dbms_assert.simple_sql_name(trim(substr(r.entry, instr(r.entry, '=') + 1))));
            else
                l_map(lower(r.entry)) := upper(dbms_assert.simple_sql_name(r.entry));
            end if;
        end loop;

        -- column data types
        if instr(l_table, '.') > 0 then
            l_owner := upper(trim('"' from substr(l_table, 1, instr(l_table, '.') - 1)));
            l_name  := upper(trim('"' from substr(l_table, instr(l_table, '.') + 1)));
        else
            l_owner := sys_context('userenv', 'current_schema');
            l_name  := upper(trim('"' from l_table));
        end if;
        for r in (select column_name, data_type from all_tab_columns where owner = l_owner and table_name = l_name) loop
            l_types(r.column_name) := r.data_type;
        end loop;
        if l_types.count = 0 then
            raise_application_error(-20001, 'save_edits: table ' || l_table || ' not found.');
        end if;

        l_arr := json_array_t.parse(p_edits);
        for i in 0 .. l_arr.get_size - 1 loop
            l_obj  := treat(l_arr.get(i) as json_object_t);
            l_id   := str(l_obj, 'id');
            l_ver  := str(l_obj, 'version');
            l_keys := l_obj.get_keys;
            l_set  := null;
            l_vals := apex_t_varchar2();
            for k in 1 .. l_keys.count loop
                if l_keys(k) not in ('id', 'version') and l_map.exists(lower(l_keys(k))) then
                    l_col := l_map(lower(l_keys(k)));
                    if not l_types.exists(l_col) then
                        raise_application_error(-20001, 'save_edits: column ' || l_col || ' not found in ' || l_table || '.');
                    end if;
                    l_vals.extend;
                    l_vals(l_vals.count) := str(l_obj, l_keys(k));
                    l_set := l_set || case when l_set is not null then ', ' end || l_col || ' = '
                          || case
                                 when l_types(l_col) = 'DATE' then
                                     'to_date(substr(:b' || l_vals.count || ', 1, 10), ''' || c_iso || ''')'
                                 when l_types(l_col) like 'TIMESTAMP%' then
                                     'to_timestamp(substr(:b' || l_vals.count || ', 1, 10), ''' || c_iso || ''')'
                                 when l_types(l_col) in ('NUMBER', 'FLOAT', 'BINARY_DOUBLE', 'BINARY_FLOAT', 'INTEGER') then
                                     'to_number(:b' || l_vals.count || ', ''9999999999999999999999999D99999999999999999999'', ''' || replace(c_nls, '''', '''''') || ''')'
                                 else ':b' || l_vals.count
                             end;
                end if;
            end loop;

            if l_set is not null then
                l_sql := 'update ' || l_table || ' set ' || l_set
                      || ' where ' || l_pk || ' = :pk'
                      || case when p_version_expr is not null then ' and (' || p_version_expr || ') = :ver' end
                      || case when p_where is not null then ' and (' || p_where || ')' end;
                l_cur := dbms_sql.open_cursor;
                begin
                    dbms_sql.parse(l_cur, l_sql, dbms_sql.native);
                    for b in 1 .. l_vals.count loop
                        dbms_sql.bind_variable(l_cur, ':b' || b, l_vals(b), 32767);
                    end loop;
                    dbms_sql.bind_variable(l_cur, ':pk', l_id);
                    if p_version_expr is not null then
                        dbms_sql.bind_variable(l_cur, ':ver', l_ver);
                    end if;
                    l_rows := dbms_sql.execute(l_cur);
                    dbms_sql.close_cursor(l_cur);
                exception
                    when others then
                        if dbms_sql.is_open(l_cur) then
                            dbms_sql.close_cursor(l_cur);
                        end if;
                        raise;
                end;
                if l_rows = 0 then
                    raise_application_error(-20002, p_record_name || ' ' || l_id
                        || ' was changed by someone else or can no longer be edited. Reload and redo the change.');
                end if;
                l_count := l_count + l_rows;
            end if;
        end loop;
        return l_count;
    end save_edits;
end ign_config_detail;
/
