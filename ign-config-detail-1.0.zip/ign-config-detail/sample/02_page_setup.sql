/* =============================================================================
   IGN Configurable Detail: sample page settings (DV_CUSTOMERS)
   Summary = one card per customer. Detail = editable form when a card expands.
   Not a script to run: copy each block into the Page Designer property named
   above it. Example page number 10; change P10_ to your page number.
   Run 01_dv_customers.sql first.
   ============================================================================= */

/* -----------------------------------------------------------------------------
   STEP 1. Page items (Region: any, e.g. a hidden "Items" region)
     P10_EDITS   Type Hidden, Value Protected = No
   ----------------------------------------------------------------------------- */

/* -----------------------------------------------------------------------------
   STEP 2. Region: Create Region, Type = IGN Configurable Detail
     Static ID            : cust
     Source > SQL Query   : the MAIN QUERY below (the summary cards)
   ----------------------------------------------------------------------------- */
select customer_id,                                         -- = Primary Key Column
       name || ' (' || customer_id || ')'  as row_label,    -- used in messages
       ora_hash(name || '|' || company_name || '|' || phone || '|' || email || '|' ||
                address || '|' || city || '|' || state || '|' || zip_code) as row_version,  -- lost-update check
       name || ' ' || company_name || ' ' || email || ' ' || city as search_text,
       name,
       company_name                         as name__sub,   -- 2nd line under NAME
       email,
       phone,
       city,
       state                                as city__sub,
       state                                as city__badge
  from dv_customers
 order by name;

/* -----------------------------------------------------------------------------
   STEP 3. Region > Attributes
     Primary Key Column : CUSTOMER_ID
     Edits Item         : P10_EDITS
     Selection Item     : (leave empty)
     Record Name        : Customer
     Search Placeholder : Search customers
     Date Format        : DD-MON-YYYY
     Detail Query       : below (column mode: one field per column)
   ----------------------------------------------------------------------------- */
select customer_id,
       'DISPLAY'  as customer_id__type,
       'Customer' as customer_id__group,
       'Customer ID' as customer_id__label,

       name,
       'TEXT'     as name__type,
       'Y'        as name__req,
       'Customer' as name__group,

       company_name,
       'TEXT'     as company_name__type,
       'Customer' as company_name__group,

       email,
       'TEXT'     as email__type,
       'Y'        as email__req,
       'Contact'  as email__group,

       phone,
       'TEXT'     as phone__type,
       'Contact'  as phone__group,
       'e.g. +62 812...' as phone__placeholder,

       address,
       'TEXTAREA' as address__type,
       'Address'  as address__group,

       city,
       'TEXT'     as city__type,
       'Address'  as city__group,
       'address IS NOT NULL' as city__required_when,     -- dynamic: required once address is filled

       state,
       'LOV'      as state__type,
       'STATES'   as state__lov,
       'Address'  as state__group,

       zip_code,
       'TEXT'     as zip_code__type,
       'Address'  as zip_code__group,
       'state IS NULL' as zip_code__readonly_when        -- dynamic: locked until a state is picked
  from dv_customers
 where customer_id = :PK;

/* -----------------------------------------------------------------------------
   LOV Query attribute
   ----------------------------------------------------------------------------- */
select 'STATES' as lov_name,
       state    as return_value,
       state    as display_value
  from (select distinct state from dv_customers where state is not null)
 order by state;

/* -----------------------------------------------------------------------------
   STEP 4. Button SAVE (Action = Defined by Dynamic Action)
     Dynamic Action on click > Execute JavaScript Code:

       apex.region("cust").submit({ request: "SAVE", validate: true });

   STEP 5. Process (Processing, Server-side Condition: Request = SAVE)
     Type PL/SQL Code:
   ----------------------------------------------------------------------------- */
declare
    l_rows pls_integer;
begin
    l_rows := ign_config_detail.save_edits(
                  p_edits       => :P10_EDITS,
                  p_table_name  => 'DV_CUSTOMERS',
                  p_pk_column   => 'CUSTOMER_ID',
                  p_columns     => 'NAME,COMPANY_NAME,PHONE,EMAIL,ADDRESS,CITY,STATE,ZIP_CODE',
                  p_version_expr => q'[ora_hash(name || '|' || company_name || '|' || phone || '|' || email || '|' ||
                                       address || '|' || city || '|' || state || '|' || zip_code)]',
                  p_record_name => 'Customer' );
    apex_application.g_print_success_message := l_rows || ' customer(s) saved.';
end;
/
